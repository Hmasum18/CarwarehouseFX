package com.company;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ReadThreadServer implements Runnable {
    private final Thread thr;
    private final NetworkUtil networkUtil;
    public HashMap<String, String> userMap;
    public List<Car> carList;
    public static int threadCount;
    public static ReadThreadServer[] threadServers=new ReadThreadServer[100];


    public ReadThreadServer(HashMap<String, String> map, NetworkUtil networkUtil) {
        this.userMap = map;
        this.networkUtil = networkUtil;
        carList=File.readFile();
        threadServers[threadCount++]=this;
        this.thr = new Thread(this);
        thr.start();
    }

    public void update(List<Car>carList) throws IOException {
        for(int i=0;i<threadCount;i++)
        {
            threadServers[i].networkUtil.write(carList);
        }

    }

    public void run() {
        try {
            while (true) {
                Object o = networkUtil.read();
                if (o != null) {
                    if (o instanceof LoginDTO) {
                        LoginDTO loginDTO = (LoginDTO) o;
                        String userName = loginDTO.getUserName();
                        if(userName.equals("viewer")){
                            loginDTO.setStatus(true);
                        }
                        else {
                            String password = userMap.get(loginDTO.getUserName());
                            loginDTO.setStatus(loginDTO.getPassword().equals(password));
                        }
                        networkUtil.write(loginDTO);
                        if(loginDTO.isStatus()){
                            networkUtil.write(carList);
                            if(loginDTO.getUserName().equals("viewer"))
                                networkUtil.write("viewer");
                            else
                                networkUtil.write("Manufacturer");
                        }
                    }
                    else if(o instanceof ArrayList)
                    {
                        update(carList);
                    }
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            try {
                networkUtil.closeConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
