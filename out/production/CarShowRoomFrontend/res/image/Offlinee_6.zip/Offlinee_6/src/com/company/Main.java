package com.company;
import java.io.IOException;

import java.util.Scanner;

public class Main {
    private NetworkUtil networkUtil;

    public NetworkUtil getNetworkUtil() {
        return networkUtil;
    }

    public void ConnectToServer() throws IOException {
        String serverAddress = "127.0.0.1";
        int serverPort = 2000;

        networkUtil = new NetworkUtil("LocalHost", 2000);
        new ReadThread(this);
    }

    public void ShowLogin() throws IOException{
        Scanner scanner=new Scanner(System.in);
        //networkUtil = new NetworkUtil("127.0.0.1", 33333);
        //new ReadThread(this);
        System.out.println("Enter username");
        String username=scanner.nextLine();
        System.out.println("Enter password");
        String password=scanner.nextLine();
        LoginDTO loginDTO=new LoginDTO();
        loginDTO.setUserName(username);
        loginDTO.setPassword(password);
        networkUtil.write(loginDTO);
    }

    public static void main(String[] args) throws IOException {

        Main instance = new Main();
        instance.ConnectToServer();
        instance.ShowLogin();
	// write your code here
    }
}
