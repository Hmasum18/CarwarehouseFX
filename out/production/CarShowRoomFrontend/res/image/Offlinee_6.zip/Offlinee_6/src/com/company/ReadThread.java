package com.company;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ReadThread implements Runnable {
    private final Thread thr;
    private final Main main;
    Scanner scanner = new Scanner(System.in);
    public ReadThread(Main main) {
        this.main = main;
        this.thr = new Thread(this);
        thr.start();
    }

    public void run() {
        try {
            while (true) {
                Object o = main.getNetworkUtil().read();
                String clientType;
                List<Car> carList = new ArrayList<>();
                if (o != null) {
                    if (o instanceof LoginDTO) {
                        LoginDTO loginDTO = (LoginDTO) o;
                        //System.out.println(loginDTO.getUserName());
                        if(loginDTO.isStatus()) {
                            System.out.println("login successful");
                        }
                        else System.out.println("login unsuccessful");

                    }
                    else if(o instanceof String)
                    {
                        clientType = (String) o;
                        if(clientType.equals("viewer")){
                            for(int i=0;i<carList.size();i++)
                                System.out.println(carList.get(i));
                            while(true){
                                System.out.print("1)view all cars\n" +
                                        "2)search car by registration number\n" +
                                        "3)search car by make and model\n" +
                                        "4)buy a car\n");
                                boolean found=false;
                                int option = scanner.nextInt();
                                switch(option){
                                    case 1:
                                        for(int i=0; i<carList.size();i++){
                                            System.out.println(carList.get(i).toString());
                                        }
                                        break;
                                    case 2:
                                        System.out.print("enter registration number: ");
                                        String reg = scanner.next();
                                        for(int i=0;i<carList.size();i++){
                                            if(carList.get(i).getCarReg().equalsIgnoreCase(reg))
                                            {
                                                System.out.println(carList.get(i).toString());
                                                found=true;
                                            }
                                        }
                                        if(found==false)
                                            System.out.println("No such car with this Registration Number");
                                        break;
                                    case 3:
                                        System.out.println("enter car make and model: ");
                                        String carMake = scanner.next();
                                        String carModel = scanner.next();
                                        if(carModel.equalsIgnoreCase("ANY"))
                                        {

                                            for(int i=0;i<carList.size();i++)
                                            {
                                                if(carList.get(i).getCarMake().equalsIgnoreCase(carMake))
                                                {
                                                    found=true;
                                                    System.out.println(carList.get(i));
                                                }

                                            }
                                            if(found==false)
                                            {
                                                System.out.println("The given car maker was not found");
                                            }
                                        }
                                        else
                                        {
                                            for(int i=0;i<carList.size();i++)
                                            {
                                                if(carList.get(i).getCarMake().equalsIgnoreCase(carMake) && carList.get(i).getCarModel().equalsIgnoreCase(carModel))
                                                {
                                                    System.out.println(carList.get(i));
                                                    found=true;
                                                }
                                            }
                                            if(found==false)
                                            {
                                                System.out.println("No such car with the given make and model found");
                                            }
                                        }
                                        break;
                                    case 4:
                                        System.out.println("Enter a registration number");
                                        String registration=scanner.next();
                                        for(int i=0;i<carList.size();i++)
                                        {
                                            System.out.println(carList.get(i));
                                            if(carList.get(i).getCarReg().equals(registration))
                                            {
                                                carList.get(i).setQuantity(carList.get(i).getQuantity()-1);
                                                System.out.println("Car sold!");
                                                break;
                                            }
                                        }
                                        main.getNetworkUtil().write(carList);
                                        //code for buying a car
                                }
                            }
                        }
                        else if(clientType.equals("Manufacturer")){
                            while(true){
                                System.out.print("1)view all cars\n" +
                                        "2)add a car\n" +
                                        "3)edit a car\n" +
                                        "delete a car\n");
                                boolean found=false;
                                int option = scanner.nextInt();
                                switch(option){
                                    case 1:
                                        for(int i=0; i<carList.size();i++){
                                            System.out.println(carList.get(i).toString());
                                        }
                                        break;
                                    case 2:
                                        MenuOperations.addCar(carList);
                                        main.getNetworkUtil().write(carList);
                                    case 3:
                                        System.out.println("Search by registration:Which car do you want to edit?");
                                        String REG=scanner.next();
                                        Car car=null;
                                        for(int i=0;i<carList.size();i++)
                                        {
                                            if(carList.get(i).getCarReg().equals(REG))
                                                car=carList.get(i);
                                        }
                                        System.out.println("Which fields do you want to edit?Enter 0 for exiting");
                                        System.out.println("1)Registration number");
                                        System.out.println("2)Year made");
                                        System.out.println("3)Colour1");
                                        System.out.println("4)Colour2");
                                        System.out.println("5)Colour3");
                                        System.out.println("6)Make");
                                        System.out.println("7)Model");
                                        System.out.println("8)Price");
                                        System.out.println("9)Quantity");
                                        boolean flag=true;
                                        while(flag)
                                        {
                                            int opt=scanner.nextInt();
                                            switch (opt)
                                            {
                                                case 1:
                                                    System.out.println("Enter new registration number");
                                                    car.setCarReg(scanner.next());
                                                    break;
                                                case 2:
                                                    System.out.println("Enter new year");
                                                    car.setYearMade(scanner.nextInt());
                                                    break;
                                                case 3:
                                                    System.out.println("Enter new colour");
                                                    car.setColour1(scanner.next());
                                                    break;
                                                case 4:
                                                    System.out.println("Enter new colour");
                                                    car.setColour2(scanner.next());
                                                    break;
                                                case 5:
                                                    System.out.println("Enter new colour");
                                                    car.setColour3(scanner.next());
                                                    break;
                                                case 6:
                                                    System.out.println("Enter new car make");
                                                    car.setCarMake(scanner.next());
                                                    break;
                                                case 7:
                                                    System.out.println("Enter new car model");
                                                    car.setCarModel(scanner.next());
                                                    break;
                                                case 8:
                                                    System.out.println("Enter new price");
                                                    car.setPrice(scanner.nextInt());
                                                    break;
                                                case 9:
                                                    System.out.println("Enter new quantity");
                                                    car.setQuantity(scanner.nextInt());
                                                    break;
                                                case 0:
                                                    flag=false;
                                            }
                                            main.getNetworkUtil().write(carList);
                                        }
                                        //add code here
                                    case 4:
                                        MenuOperations.delCar(carList);
                                        main.getNetworkUtil().write(carList);

                                }

                            }
                        }
                    }
                    else{
                        carList = (List<Car>)o;
                    }
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            try {
                main.getNetworkUtil().closeConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
